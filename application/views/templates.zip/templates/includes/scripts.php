  <script src="front/js/jquery.js"></script> 
	<script src="front/js/popper.min.js"></script>
	<script src="front/js/bootstrap.min.js"></script>
	<script src="front/js/jquery.fancybox.js"></script>
	<script src="front/js/mmenu.polyfills.js"></script>
	<script src="front/js/jquery.modal.min.js"></script>
	<script src="front/js/jquery-validation.min.js"></script>
	<script src="front/js/mmenu.js"></script>
	<script src="front/js/jquery-ui.min.js"></script>
	<script src="front/js/appear.js"></script>
	<script src="front/js/owl.js"></script>
	<script src="front/js/wow.js"></script>
	<script src="front/js/script.js"></script>
	
	
	
