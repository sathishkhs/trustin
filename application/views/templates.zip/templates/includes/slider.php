<!-- Bnner Section One -->
<section class="banner-section-one">
  <div class="banner-carousel owl-carousel owl-theme default-arrows dark">
    <div class="slide-item banner-1" style="background-image: url(front/images/Home_Banner_4.jpg);">
      <div class="auto-container">
        <div class="content-outer">
          <div class="content-box">
            <h2><span style="color:#2a5aa9">Trust-in</span> Hospital</h2>
            <div class="text ">Brings quality healthcare within your reach!</div>
            <!-- <div class="btn-box">
									<a href="#" class="btn-style"><span class="btn-title">About Us</span></a>
								</div> -->
          </div>
        </div>
      </div>
    </div>

    <div class="slide-item banner-2" style="background-image: url(front/images/banner-2.jpg);">
      <div class="auto-container">
        <div class="content-outer">
          <!-- <div class="content-box">
								<span class="title">Welcome to our Medical Care Center</span>
								<h2>We take care our <br>patients health</h2>
								<div class="text">I realized that becoming a doctor, I can only help a small community. <br>But by becoming a doctor, I can help my whole country. </div>
							</div> -->
        </div>
      </div>
    </div>
  </div>
</section>
<!-- End Bnner Section One -->