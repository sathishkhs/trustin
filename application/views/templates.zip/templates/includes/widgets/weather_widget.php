baba
<?php if(isset($w->advertiser_content_type)) {?>	
	<div class="col-md-12 col-sm-12" style="margin-bottom:10px;text-align: center;">
		<?php echo $w->advertiser_content; ?>
	</div>
<?php } ?>