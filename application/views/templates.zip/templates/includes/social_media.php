<ul id="socialslide">
    <li class="button-color-1">
		<a href="<?php echo $settings->FACEBOOK_LINK; ?>" title="" target="_blank"><img src="<?php echo $base_url.'images/facebook_icon.png';?>"></a>
	</li>
    <li class="button-color-2">
		<a href="<?php echo $settings->TWITTER_LINK; ?>" title="" target="_blank"><img src="<?php echo $base_url.'images/twitter.jpg';?>"></a>
	</li>
	<li class="button-color-3">
		<a href="<?php echo $settings->GOOGLE_PLUS; ?>" title="" target="_blank"><img src="<?php echo $base_url.'images/google_plus_icon.png';?>"></a>
	</li>
</ul>



