	<!-- Bnner Section One -->
    <section class="hero-about-area" style="background-image: url(<?php echo BANNER_IMAGE_PATH.$banner_image; ?>);">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="hero-about-text text-center">
							<h2><?php echo $page_heading; ?></h2>
							<h4><?php echo $breadcrumb; ?></h4>
						</div>
					</div>
				</div>
			</div>
		</section>