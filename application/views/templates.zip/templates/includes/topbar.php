	<!-- Header top -->
	<div class="header-top">
	    <div class="auto-container">
	        <div class="inner-container">
	            <div class="top-left">
	                <ul class="contact-list clearfix">
	                    <!--<li><i class="far fa-clock"></i>Mon - Sat 8.00 - 18.00. Sunday CLOSED</li>-->
	                </ul>
	            </div>
	            <div class="top-right">
	                <ul class="social-icon-one">
	                    <li><i class="fas fa-headset"></i> <?php echo $settings->TELEPHONE_NUM;?> &nbsp;</li>
	                    <li><a href="<?php echo $settings->FACEBOOK_LINK; ?>"><span class="fab fa-facebook-f"></span></a></li>
	                    <li><a href="<?php echo $settings->TWITTER_LINK; ?>"><span class="fab fa-twitter"></span></a></li>
	                    <li><a href="<?php echo $settings->INSTAGRAM_LINK; ?>"><span class="fab fa-instagram"></span></a></li>
	                    <li><a href="<?php echo $settings->LINKEDIN_LINK; ?>"><span class="fab fa-linkedin-in"></span></a></li>
	                </ul>
	            </div>
	        </div>
	    </div>
	</div>
	<!-- End Header Top -->