<footer class="main-footer">

    <div class="pull-right hidden-xs">

      <b>Version</b> 1.0

    </div>

    <strong>Copyright &copy; 2018 <a href="http://www.creativeyogi.in/">Creative Yogi</a>.</strong> All rights

    reserved.

</footer>

